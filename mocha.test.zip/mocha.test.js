const minhaFuncao = require('../minha-funcao'); // mocha.test.js
const assert = require('chai).assert;

describe('Minha Função', function () {
    it('Deve retornar true quando chamada com true', function
       assert.strictEqual(minhaFuncao(true), true);
   });

    it('Deve retornar false quando chamada com false',function () {
      assert.strictEqual(minhaFuncao(false), false);
   });
});
   
