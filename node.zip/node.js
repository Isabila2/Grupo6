const nunjucks = require('nunjucks');
const express = require('express');
const app = express();

// Configurando a pasta onde estão os templates
nunjucks.configure('templates', {
  autoescape: true,
  express: app
});

// Rota para renderizar um template
app.get('/', (req, res) => {
  // Dados que serão passados para o template
  const data = {
    title: 'Exemplo de Template Engine Nunjucks',
    content: 'Este é um exemplo simples de como usar Nunjucks para renderizar modelos.'
  };

  // Renderizando o template
  res.render('index.html', data);
});

app.listen(8080, () => {
  console.log('Servidor escutando na porta 8080');
});
