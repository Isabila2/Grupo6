const express = require('express');
const cors = require('cors');

const app = express();
const PORT = 3000;

// Middleware CORS
app.use(cors());

// Rota de exemplo que retorna dados JSON
app.get('/api/data', (req, res) => {
  const data = {
    message: 'Acesso permitido! Esses dados são públicos.',
  };
  res.json(data);
});

app.listen(PORT, () => {
  console.log(`Servidor está executando na porta ${PORT}`);
});
